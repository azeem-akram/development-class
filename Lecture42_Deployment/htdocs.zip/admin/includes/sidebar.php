<div class="sidebar">
    <div class="p-3">
        <img src="/assets/images/logo.png" width="50px"/> <span> <?php echo $_SESSION['admin_first_name'] ?> <?php echo $_SESSION['admin_last_name'] ?> </span>
    </div>


    <div class="nav">
        <a href="/admin/dashboard.php" class="nav-link">Home</a>
        <a href="/admin/blog-posts.php" class="nav-link">Manage Blog Posts</a>
        <a href="/admin/categories.php" class="nav-link">Manage Categories</a>
        <a href="/admin/users.php" class="nav-link">Manage Users</a>
        <a href="/admin/comments.php"  class="nav-link">Mannage Comments</a>
        <a href="/admin/logout.php" class="nav-link">Logout</a>
    </div>


</div>