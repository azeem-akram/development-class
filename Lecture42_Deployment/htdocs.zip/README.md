
## Lecture 42
    - Create a Database & Its user
        1) Crate a database
        2) Crate a user for the database
        3) Add user to the database
        4) Add permission for the user (We will assign all permissions)
        4) Import SQL file into the database

    - Upload Files
        1) Zip all the files of the website
        2) Go to file manager
        3) Upload files in a Website folder
          1) Create a sub domain
          2) Upload zip file in the sub domain folder
          3) Extract Zip file


    - Change Database connection variables
        $username = "toptcszk_blog_user";
        $password = "bjp0H4!JkyB=";
        $databaseName = "toptcszk_blog";

    

    - Website should be live



## Next Class
    
    

    