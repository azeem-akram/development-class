<footer class="bg-dark text-white text-center p-5">
    Copyright Developement Class
</footer>